import React, { useState, useEffect, useRef } from 'react';
import {
  SimulationState,
  generateSolvableEnvironment,
  createSimulationState,
  executeSimulationStep,
  toKey,
} from '../simulation/logic';
import { sectorMemoryRegistry } from '../simulation/sectorMemory';
import { stateStore } from '../storage/stateStore';
import { RobotUnit, MissionReport, SectorMemory, GroundTruth } from '../types';
import { TacticalGrid } from '../components/grid/TacticalGrid';
import { ReasoningLog } from '../components/hud/ReasoningLog';
import { TelemetryPanel } from '../components/hud/TelemetryPanel';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import { Slider } from '../components/ui/Slider';
import { Modal } from '../components/ui/Modal';
import {
  Play,
  Pause,
  StepForward,
  FastForward,
  RotateCcw,
  Rocket,
  ShieldAlert,
  CheckCircle,
  HelpCircle,
  AlertTriangle,
} from 'lucide-react';

interface MissionControlPageProps {
  initialSector?: string;
  initialRobotId?: string;
}

export const MissionControlPage: React.FC<MissionControlPageProps> = ({
  initialSector,
  initialRobotId,
}) => {
  // Setup State
  const [sectorName, setSectorName] = useState<string>(initialSector || 'SECTOR-ALPHA');
  const [fleet, setFleet] = useState<RobotUnit[]>([]);
  const [selectedUnitId, setSelectedUnitId] = useState<string>('');
  const [activeMemory, setActiveMemory] = useState<SectorMemory | null>(null);

  // Active Simulation State
  const [isMissionActive, setIsMissionActive] = useState<boolean>(false);
  const [groundTruth, setGroundTruth] = useState<GroundTruth | null>(null);
  const [simulationState, setSimulationState] = useState<SimulationState | null>(null);
  const [activeUnit, setActiveUnit] = useState<RobotUnit | null>(null);

  // Playback Controls
  const [autoRunning, setAutoRunning] = useState<boolean>(false);
  const [playbackSpeedMs, setPlaybackSpeedMs] = useState<number>(300);
  const [commandPeek, setCommandPeek] = useState<boolean>(false);

  // Outcome Summary Modal
  const [showOutcomeModal, setShowOutcomeModal] = useState<boolean>(false);

  // Auto-run interval timer ref
  const timerRef = useRef<number | null>(null);

  // Load Fleet & Sector Memory on Mount
  useEffect(() => {
    const updateData = () => {
      const units = stateStore.getFleet();
      setFleet(units);

      // Default to initialRobotId or first standby unit
      const standbyUnits = units.filter((u) => u.status === 'STANDBY');
      if (initialRobotId && units.some((u) => u.id === initialRobotId && u.status === 'STANDBY')) {
        setSelectedUnitId(initialRobotId);
      } else if (standbyUnits.length > 0 && !selectedUnitId) {
        setSelectedUnitId(standbyUnits[0].id);
      }
    };

    updateData();
    const unsubscribe = stateStore.subscribe(updateData);
    return () => unsubscribe();
  }, [initialRobotId]);

  // Check sector memory whenever sectorName changes
  useEffect(() => {
    if (sectorName.trim()) {
      const mem = sectorMemoryRegistry.getSectorMemory(sectorName);
      setActiveMemory(mem);
    } else {
      setActiveMemory(null);
    }
  }, [sectorName]);

  // Auto-run step effect
  useEffect(() => {
    if (autoRunning && isMissionActive && simulationState?.status === 'IN_PROGRESS') {
      timerRef.current = window.setTimeout(() => {
        handleStepForward();
      }, playbackSpeedMs);
    } else if (simulationState && simulationState.status !== 'IN_PROGRESS') {
      setAutoRunning(false);
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [autoRunning, simulationState, playbackSpeedMs, isMissionActive]);

  // Handle Mission Deployment
  const handleDeployMission = () => {
    if (!selectedUnitId) return;

    const unit = stateStore.getUnitById(selectedUnitId);
    if (!unit || unit.status !== 'STANDBY') return;

    // 1. Determine environment layout:
    // If sector memory exists from a prior fallen unit, reuse EXACT ground truth!
    let env: GroundTruth;
    const existingMemory = sectorMemoryRegistry.getSectorMemory(sectorName);

    if (existingMemory) {
      env = existingMemory.groundTruth;
      setActiveMemory(existingMemory);
    } else {
      env = generateSolvableEnvironment();
      setActiveMemory(null);
    }

    // 2. Initialize robot simulation state with inherited memory if available
    const initialState = createSimulationState(existingMemory);

    setGroundTruth(env);
    setSimulationState(initialState);
    setActiveUnit(unit);
    setIsMissionActive(true);
    setAutoRunning(false);

    // Update unit status in roster
    stateStore.updateUnitStatus(unit.id, 'DEPLOYED', sectorName);
  };

  // Handle Atomic Step Forward
  const handleStepForward = () => {
    if (!simulationState || !groundTruth || simulationState.status !== 'IN_PROGRESS') return;

    const nextState = executeSimulationStep(simulationState, groundTruth);
    setSimulationState(nextState);

    // Check for mission conclusion
    if (nextState.status !== 'IN_PROGRESS') {
      setAutoRunning(false);
      handleMissionConcluded(nextState);
    }
  };

  // Fast forward to end of simulation
  const handleFastFinish = () => {
    if (!simulationState || !groundTruth || simulationState.status !== 'IN_PROGRESS') return;

    let curr = simulationState;
    let guard = 0;
    while (curr.status === 'IN_PROGRESS' && guard < 250) {
      curr = executeSimulationStep(curr, groundTruth);
      guard++;
    }

    setSimulationState(curr);
    setAutoRunning(false);
    handleMissionConcluded(curr);
  };

  // Handle Mission Conclusion (Record Incident, Sector Memory, Unit Roster)
  const handleMissionConcluded = (finalState: SimulationState) => {
    if (!activeUnit || !groundTruth) return;

    const isSuccess = finalState.status === 'SUCCESS_EXTRACTED';
    const isDestroyed = finalState.status === 'UNIT_DESTROYED';
    const isNoSurvivor = finalState.status === 'NO_SURVIVOR_FOUND';

    // 1. Update Unit Status in Roster
    if (isDestroyed) {
      stateStore.updateUnitStatus(activeUnit.id, 'DESTROYED', sectorName);
    } else {
      stateStore.updateUnitStatus(activeUnit.id, 'STANDBY', sectorName);
    }

    // 2. Manage Sector Memory:
    // Core Promise: If destroyed, save sector memory so next deployment reuses layout & inherits intelligence!
    // If success or no survivor, clear sector memory so next deployment generates fresh layout!
    if (isDestroyed && finalState.fatalBreach) {
      const confirmedObj: Record<string, any> = {};
      finalState.confirmedHazards.forEach((val, key) => {
        confirmedObj[key] = val;
      });

      sectorMemoryRegistry.recordSectorCasualty(
        sectorName,
        groundTruth,
        Array.from(finalState.provenSafe),
        confirmedObj,
        activeUnit.id,
        finalState.fatalBreach.position
      );
    } else if (isSuccess || isNoSurvivor) {
      sectorMemoryRegistry.clearSectorMemory(sectorName);
    }

    // 3. Persist Mission Report
    const report: MissionReport = {
      id: `rep-${Date.now()}`,
      timestamp: new Date().toISOString(),
      sectorName,
      unitId: activeUnit.id,
      unitCallsign: activeUnit.callsign,
      outcome: finalState.status,
      totalSteps: finalState.step,
      cellsExploredCount: finalState.visited.size,
      survivorRescued: finalState.survivorRescued,
      hazardEncountered: finalState.fatalBreach?.hazardType,
      fatalCoordinate: finalState.fatalBreach?.position,
      inheritedMemoryUsed: !!activeMemory,
      reasoningLog: finalState.reasoningLog,
    };

    stateStore.addReport(report);
    setShowOutcomeModal(true);
  };

  // Reset / Abort Mission
  const handleResetMission = () => {
    if (activeUnit && isMissionActive && simulationState?.status === 'IN_PROGRESS') {
      stateStore.updateUnitStatus(activeUnit.id, 'STANDBY');
    }
    setAutoRunning(false);
    setIsMissionActive(false);
    setSimulationState(null);
    setGroundTruth(null);
    setActiveUnit(null);
    setShowOutcomeModal(false);
  };

  const standbyUnits = fleet.filter((u) => u.status === 'STANDBY');

  return (
    <div className="space-y-6">
      {/* Sector Memory Inheritance Banner */}
      {activeMemory && (
        <Alert
          variant="warning"
          title={`INHERITED SECTOR MEMORY DETECTED: ${activeMemory.sectorName}`}
          className="border-amber-500/50 bg-amber-950/40"
          action={
            <Badge variant="amber" dot>
              Memory Active
            </Badge>
          }
        >
          A previous unit (<span className="font-bold text-amber-300">{activeMemory.failedByUnitId}</span>) was destroyed at coordinate{' '}
          <span className="font-bold text-red-300">
            ({activeMemory.casualtyPosition[0]},{activeMemory.casualtyPosition[1]})
          </span>. 
          Deploying here will <strong className="text-amber-200">reuse the exact layout</strong> and pre-populate{' '}
          <strong className="text-teal-300">{activeMemory.provenSafeKeys.length} proven-safe sectors</strong>. 
          The replacement unit will visibly steer clear of the fatal hazard!
        </Alert>
      )}

      {/* Deployment Bar (When not active) */}
      {!isMissionActive ? (
        <Card className="border border-white/10 shadow-xl">
          <CardHeader className="bg-slate-900/80">
            <CardTitle className="text-amber-400 flex items-center gap-2">
              <Rocket className="w-5 h-5 text-amber-400" />
              DEPLOY AUTONOMOUS RESCUE MISSION
            </CardTitle>
            <Badge variant="slate">Mission Setup Protocol</Badge>
          </CardHeader>

          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div>
                <label className="block text-xs font-mono-hud font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Target Sector Designation
                </label>
                <Input
                  value={sectorName}
                  onChange={(e) => setSectorName(e.target.value)}
                  placeholder="e.g. SECTOR-ALPHA, ZONE-9"
                  className="font-bold uppercase tracking-wider"
                />
                <div className="mt-2 flex items-center gap-2 text-[11px] font-mono-hud text-slate-500">
                  <span>Quick Sectors:</span>
                  {['SECTOR-ALPHA', 'SECTOR-BETA', 'SECTOR-GAMMA'].map((s) => (
                    <button
                      key={s}
                      onClick={() => setSectorName(s)}
                      className="text-amber-400 hover:text-amber-300 underline cursor-pointer"
                    >
                      {s.replace('SECTOR-', '')}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-hud font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Select Standby Unit ({standbyUnits.length} Available)
                </label>
                <select
                  value={selectedUnitId}
                  onChange={(e) => setSelectedUnitId(e.target.value)}
                  className="w-full bg-slate-950/80 text-slate-100 font-mono-hud text-xs md:text-sm px-3.5 py-2.5 rounded-md border border-slate-700/60 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400"
                >
                  {standbyUnits.length === 0 ? (
                    <option value="">No standby units available (all deployed/destroyed)</option>
                  ) : (
                    standbyUnits.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.id} - {u.callsign} ({u.team})
                      </option>
                    ))
                  )}
                </select>
                <p className="mt-1.5 text-[11px] font-mono-hud text-slate-500">
                  Unit will navigate with local sensors and propositional logic only.
                </p>
              </div>

              <div>
                <Button
                  variant="amber"
                  size="lg"
                  className="w-full h-[44px]"
                  icon={<Rocket className="w-4 h-4" />}
                  onClick={handleDeployMission}
                  disabled={standbyUnits.length === 0 || !selectedUnitId || !sectorName.trim()}
                >
                  DEPLOY RESCUEBOT
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        /* Mission Execution Control Bar */
        <Card className="border border-amber-500/30 glass-panel-amber">
          <div className="p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Badge variant="teal" dot>
                MISSION ACTIVE
              </Badge>
              <div>
                <span className="font-display font-bold text-amber-200 text-base mr-2">
                  {sectorName}
                </span>
                <span className="font-mono-hud text-xs text-slate-300">
                  Unit: {activeUnit?.id} ({activeUnit?.callsign})
                </span>
              </div>
            </div>

            {/* Tactical Control Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="slate"
                size="sm"
                icon={<StepForward className="w-4 h-4 text-cyan-400" />}
                onClick={handleStepForward}
                disabled={simulationState?.status !== 'IN_PROGRESS' || autoRunning}
              >
                Step Forward
              </Button>

              <Button
                variant={autoRunning ? 'coral' : 'amber'}
                size="sm"
                icon={autoRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                onClick={() => setAutoRunning(!autoRunning)}
                disabled={simulationState?.status !== 'IN_PROGRESS'}
              >
                {autoRunning ? 'Pause Stream' : 'Auto-Run'}
              </Button>

              <Button
                variant="slate"
                size="sm"
                icon={<FastForward className="w-4 h-4 text-amber-400" />}
                onClick={handleFastFinish}
                disabled={simulationState?.status !== 'IN_PROGRESS'}
              >
                Fast Finish
              </Button>

              <Button
                variant="ghost"
                size="sm"
                icon={<RotateCcw className="w-4 h-4 text-slate-400" />}
                onClick={handleResetMission}
              >
                Abort & Return
              </Button>
            </div>

            {/* Speed Controller Slider */}
            <div className="w-40 hidden lg:block">
              <Slider
                min="50"
                max="1000"
                step="50"
                value={playbackSpeedMs}
                onChange={(e) => setPlaybackSpeedMs(Number(e.target.value))}
                valueDisplay={`${playbackSpeedMs}ms`}
                label="Stream Delay"
              />
            </div>
          </div>
        </Card>
      )}

      {/* Main Mission Control Layout: 3 Columns (Hero Grid, Log Stream, Telemetry) */}
      {isMissionActive && simulationState && groundTruth && activeUnit && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Hero Column: 5x5 Tactical Building Scan (Visual Weight Centerpiece) */}
          <div className="lg:col-span-5 space-y-4">
            <TacticalGrid
              simulationState={simulationState}
              groundTruth={groundTruth}
              commandPeek={commandPeek}
              onToggleCommandPeek={() => setCommandPeek(!commandPeek)}
            />
          </div>

          {/* Middle Column: Live AI Propositional Reasoning Log */}
          <div className="lg:col-span-4 h-full">
            <ReasoningLog entries={simulationState.reasoningLog} />
          </div>

          {/* Right Column: Sensor Telemetry & Propositional Clauses HUD */}
          <div className="lg:col-span-3 space-y-4">
            <TelemetryPanel
              simulationState={simulationState}
              sectorName={sectorName}
              unitCallsign={activeUnit.callsign}
            />
          </div>
        </div>
      )}

      {/* Mission Outcome Summary Modal */}
      {simulationState && (
        <Modal
          isOpen={showOutcomeModal}
          onClose={() => setShowOutcomeModal(false)}
          title="MISSION DEBRIEF & INCIDENT REPORT"
          subtitle={`Sector: ${sectorName} | Unit: ${activeUnit?.id}`}
        >
          <div className="space-y-5">
            {simulationState.status === 'SUCCESS_EXTRACTED' && (
              <div className="p-4 rounded-xl bg-teal-950/60 border border-teal-500/60 text-teal-100 flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-teal-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-display font-bold text-base text-teal-300">
                    SURVIVOR SUCCESSFULLY EXTRACTED
                  </h4>
                  <p className="font-sans text-xs text-teal-200 mt-1">
                    The autonomous robot successfully located the survivor, computed an optimal zero-risk
                    return route via BFS over proven safe cells, and returned safely to extraction base (0,0).
                  </p>
                </div>
              </div>
            )}

            {simulationState.status === 'UNIT_DESTROYED' && (
              <div className="p-4 rounded-xl bg-red-950/60 border border-red-500/60 text-red-100 flex items-start gap-3">
                <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-display font-bold text-base text-red-300">
                    UNIT CASUALTY REPORTED (REAL RISK OCCURRED)
                  </h4>
                  <p className="font-sans text-xs text-red-200 mt-1">
                    The unit took a calculated risk and breached an undetected{' '}
                    <strong className="text-red-300">
                      {simulationState.fatalBreach?.hazardType.replace('_', ' ')}
                    </strong>{' '}
                    at ({simulationState.fatalBreach?.position[0]},{simulationState.fatalBreach?.position[1]}).
                    The unit status has been transitioned to <span className="underline font-bold">DESTROYED</span>.
                  </p>
                  <p className="font-mono-hud text-[11px] text-amber-300 mt-2">
                    ⚡ Sector memory has been saved! The next unit deployed to "{sectorName}" will inherit this layout and avoid this breach point.
                  </p>
                </div>
              </div>
            )}

            {simulationState.status === 'NO_SURVIVOR_FOUND' && (
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 flex items-start gap-3">
                <HelpCircle className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-display font-bold text-base text-cyan-300">
                    EXHAUSTIVE SEARCH CONCLUDED (NO SURVIVOR FOUND)
                  </h4>
                  <p className="font-sans text-xs text-slate-300 mt-1">
                    All reachable safe and risk-viable perimeters were systematically explored. The unit
                    safely withdrew via BFS without casualty, concluding that no survivor was reachable in this zone.
                  </p>
                </div>
              </div>
            )}

            {/* Mission Stats Breakdown */}
            <div className="grid grid-cols-3 gap-3 text-center font-mono-hud text-xs">
              <div className="p-3 rounded-lg bg-slate-950/80 border border-white/5">
                <div className="text-slate-500 text-[10px] uppercase">Total Steps</div>
                <div className="text-base font-bold text-slate-200">{simulationState.step}</div>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/80 border border-white/5">
                <div className="text-slate-500 text-[10px] uppercase">Cells Explored</div>
                <div className="text-base font-bold text-cyan-300">
                  {simulationState.visited.size} / 25
                </div>
              </div>
              <div className="p-3 rounded-lg bg-slate-950/80 border border-white/5">
                <div className="text-slate-500 text-[10px] uppercase">Hazards Confirmed</div>
                <div className="text-base font-bold text-amber-300">
                  {simulationState.confirmedHazards.size} / 2
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <Button
                variant="slate"
                size="sm"
                onClick={() => setShowOutcomeModal(false)}
              >
                Close & Review Grid
              </Button>
              <Button
                variant="amber"
                size="sm"
                onClick={handleResetMission}
              >
                Return to Deploy Console
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
