/**
 * Classical AI Simulation Engine
 * Logic, Search, and Planning for RescueBot Command
 * Zero Machine Learning - 100% Deterministic Propositional Logic & Graph Search
 */

import {
  Coordinate,
  CellKey,
  GroundTruth,
  HazardType,
  SensorReading,
  CandidateClause,
  ReasoningLogEntry,
  MissionOutcome,
  SectorMemory,
} from '../types';

export const GRID_SIZE = 5;

export function toKey(r: number, c: number): CellKey {
  return `${r},${c}`;
}

export function fromKey(key: CellKey): Coordinate {
  const [r, c] = key.split(',').map(Number);
  return [r, c];
}

export function getNeighbors(r: number, c: number): Coordinate[] {
  const directions: Coordinate[] = [
    [-1, 0], // North
    [1, 0],  // South
    [0, -1], // West
    [0, 1],  // East
  ];

  const neighbors: Coordinate[] = [];
  for (const [dr, dc] of directions) {
    const nr = r + dr;
    const nc = c + dc;
    if (nr >= 0 && nr < GRID_SIZE && nc >= 0 && nc < GRID_SIZE) {
      neighbors.push([nr, nc]);
    }
  }
  return neighbors;
}

export function getNeighborKeys(r: number, c: number): CellKey[] {
  return getNeighbors(r, c).map(([nr, nc]) => toKey(nr, nc));
}

/**
 * Verifies survivor is reachable from (0,0) through non-hazard cells using BFS.
 */
export function isSurvivorReachable(groundTruth: GroundTruth): boolean {
  const startKey = toKey(0, 0);
  const targetKey = toKey(groundTruth.survivor[0], groundTruth.survivor[1]);

  if (groundTruth.hazards[startKey]) return false;
  if (startKey === targetKey) return true;

  const queue: Coordinate[] = [[0, 0]];
  const visited = new Set<CellKey>([startKey]);

  while (queue.length > 0) {
    const [currR, currC] = queue.shift()!;
    const currKey = toKey(currR, currC);

    if (currKey === targetKey) {
      return true;
    }

    for (const [nr, nc] of getNeighbors(currR, currC)) {
      const nKey = toKey(nr, nc);
      if (!visited.has(nKey) && !groundTruth.hazards[nKey]) {
        visited.add(nKey);
        queue.push([nr, nc]);
      }
    }
  }

  return false;
}

/**
 * Generates a valid, solvable environment with exactly 2 hazards and 1 survivor.
 * Start (0,0) is always safe.
 */
export function generateSolvableEnvironment(): GroundTruth {
  let attempts = 0;
  const maxAttempts = 1000;

  while (attempts < maxAttempts) {
    attempts++;
    const hazards: Record<CellKey, HazardType> = {};
    const hazardTypes: HazardType[] = ['STRUCTURAL_COLLAPSE', 'GAS_LEAK'];

    // All available coordinates except (0,0)
    const availableCoords: Coordinate[] = [];
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (r === 0 && c === 0) continue;
        availableCoords.push([r, c]);
      }
    }

    // Shuffle coordinates
    for (let i = availableCoords.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [availableCoords[i], availableCoords[j]] = [availableCoords[j], availableCoords[i]];
    }

    // Place exactly 2 hazards
    const h1Coord = availableCoords[0];
    const h2Coord = availableCoords[1];
    hazards[toKey(h1Coord[0], h1Coord[1])] = hazardTypes[Math.floor(Math.random() * hazardTypes.length)];
    hazards[toKey(h2Coord[0], h2Coord[1])] = hazardTypes[Math.floor(Math.random() * hazardTypes.length)];

    // Place 1 survivor in one of remaining coordinates
    const survivorCoord = availableCoords[2];

    const groundTruth: GroundTruth = {
      hazards,
      survivor: survivorCoord,
    };

    if (isSurvivorReachable(groundTruth)) {
      return groundTruth;
    }
  }

  // Fallback guaranteed layout if randomization took too long
  return {
    hazards: {
      '1,2': 'GAS_LEAK',
      '3,3': 'STRUCTURAL_COLLAPSE',
    },
    survivor: [4, 4],
  };
}

/**
 * AMBIGUOUS LOCAL SENSING
 * Critical Rule: The sensor ONLY reports boolean dangerSignal ("a danger signal is present somewhere among my neighboring cells").
 * It NEVER reveals which specific neighbor triggered it.
 * This function is the ONLY place in the entire codebase where groundTruth is accessed during simulation.
 */
export function readSensors(currentPos: Coordinate, groundTruth: GroundTruth): SensorReading {
  const currentKey = toKey(currentPos[0], currentPos[1]);
  
  // Did the robot step directly on a hazard?
  const breachedHazard = groundTruth.hazards[currentKey] || null;

  // Did the robot reach the survivor?
  const isSurvivor = currentPos[0] === groundTruth.survivor[0] && currentPos[1] === groundTruth.survivor[1];

  // Ambiguous danger signal: true if ANY 4-neighbor has a hazard
  let dangerSignal = false;
  for (const [nr, nc] of getNeighbors(currentPos[0], currentPos[1])) {
    const nKey = toKey(nr, nc);
    if (groundTruth.hazards[nKey]) {
      dangerSignal = true;
      break;
    }
  }

  return {
    dangerSignal,
    isSurvivor,
    breachedHazard,
  };
}

/**
 * Robot Simulation State
 */
export interface SimulationState {
  step: number;
  currentPos: Coordinate;
  status: MissionOutcome;
  visited: Set<CellKey>;
  provenSafe: Set<CellKey>;
  confirmedHazards: Map<CellKey, HazardType>;
  candidateClauses: CandidateClause[];
  dfsPath: Coordinate[]; // Stack for backtracking
  returnPlan: Coordinate[] | null; // Computed once upon finding survivor or abort
  returnPlanIndex: number;
  survivorLocated: boolean;
  survivorRescued: boolean;
  fatalBreach: { position: Coordinate; hazardType: HazardType } | null;
  reasoningLog: ReasoningLogEntry[];
  lastSensorReading: SensorReading | null;
}

/**
 * Initializes a new simulation state.
 * Supports sector memory inheritance if unit redeployed to same failed sector.
 */
export function createSimulationState(inheritedMemory?: SectorMemory | null): SimulationState {
  const startKey = toKey(0, 0);
  const provenSafe = new Set<CellKey>([startKey]);
  const confirmedHazards = new Map<CellKey, HazardType>();
  const initialLog: ReasoningLogEntry[] = [];

  let stepCounter = 0;

  if (inheritedMemory) {
    // Inherit knowledge from previous fallen unit
    inheritedMemory.provenSafeKeys.forEach((k) => provenSafe.add(k));
    Object.entries(inheritedMemory.confirmedHazardKeys).forEach(([k, type]) => {
      confirmedHazards.set(k, type);
    });

    initialLog.push({
      id: `init-${stepCounter++}`,
      step: 0,
      timestamp: Date.now(),
      position: [0, 0],
      type: 'OBSERVATION',
      message: `[SECTOR MEMORY LOADED] Inherited intelligence from casualty (${inheritedMemory.failedByUnitId}): ${inheritedMemory.provenSafeKeys.length} safe sectors and confirmed hazard at (${inheritedMemory.casualtyPosition[0]},${inheritedMemory.casualtyPosition[1]}).`,
      details: `Re-deploying unit with pre-established threat perimeter. Avoiding previously fatal breach point.`,
    });
  } else {
    initialLog.push({
      id: `init-${stepCounter++}`,
      step: 0,
      timestamp: Date.now(),
      position: [0, 0],
      type: 'OBSERVATION',
      message: `[DEPLOYMENT] RescueBot deployed at extraction point (0,0). No blueprint available. Activating local proximity sensors.`,
    });
  }

  return {
    step: 0,
    currentPos: [0, 0],
    status: 'IN_PROGRESS',
    visited: new Set<CellKey>([startKey]),
    provenSafe,
    confirmedHazards,
    candidateClauses: [],
    dfsPath: [[0, 0]],
    returnPlan: null,
    returnPlanIndex: 0,
    survivorLocated: false,
    survivorRescued: false,
    fatalBreach: null,
    reasoningLog: initialLog,
    lastSensorReading: null,
  };
}

/**
 * Runs Breadth-First Search strictly through PROVEN SAFE cells to find the optimal path to (0,0).
 * Guarantees zero-risk extraction.
 */
export function computeSafeReturnPath(
  start: Coordinate,
  provenSafe: Set<CellKey>
): Coordinate[] {
  const targetKey = toKey(0, 0);
  const startKey = toKey(start[0], start[1]);

  if (startKey === targetKey) {
    return [[0, 0]];
  }

  const queue: Coordinate[][] = [[[start[0], start[1]]]];
  const visited = new Set<CellKey>([startKey]);

  while (queue.length > 0) {
    const path = queue.shift()!;
    const current = path[path.length - 1];
    const currentKey = toKey(current[0], current[1]);

    if (currentKey === targetKey) {
      return path; // Path from current to [0,0]
    }

    for (const [nr, nc] of getNeighbors(current[0], current[1])) {
      const nKey = toKey(nr, nc);
      if (provenSafe.has(nKey) && !visited.has(nKey)) {
        visited.add(nKey);
        queue.push([...path, [nr, nc]]);
      }
    }
  }

  // Fallback: If somehow no safe path exists (should not happen since start is safe and connected),
  // return direct step to [0,0]
  return [[0, 0]];
}

/**
 * Evaluates suspicion score for a candidate cell.
 * Lower score = safer.
 * A cell that was NEVER named in any danger clause has suspicion = 0.
 */
export function calculateSuspicionScore(
  cellKey: CellKey,
  clauses: CandidateClause[]
): { score: number; appearances: number } {
  let score = 0;
  let appearances = 0;

  for (const clause of clauses) {
    if (clause.candidates.has(cellKey)) {
      appearances++;
      // A smaller clause concentrates danger on its members
      score += 1.0 / clause.candidates.size;
    }
  }

  return { score, appearances };
}

/**
 * Core Step Function:
 * Executes one atomic cycle of sensing, propositional reasoning (unit propagation), and action planning.
 */
export function executeSimulationStep(
  state: SimulationState,
  groundTruth: GroundTruth
): SimulationState {
  if (state.status !== 'IN_PROGRESS') {
    return state;
  }

  const nextState: SimulationState = {
    ...state,
    step: state.step + 1,
    visited: new Set(state.visited),
    provenSafe: new Set(state.provenSafe),
    confirmedHazards: new Map(state.confirmedHazards),
    candidateClauses: state.candidateClauses.map((c) => ({
      ...c,
      candidates: new Set(c.candidates),
    })),
    dfsPath: [...state.dfsPath],
    reasoningLog: [...state.reasoningLog],
  };

  const currPos = nextState.currentPos;
  const currKey = toKey(currPos[0], currPos[1]);

  // Mark current as visited & safe
  nextState.visited.add(currKey);
  nextState.provenSafe.add(currKey);

  // 1. SENSE LOCAL ENVIRONMENT
  const sensor = readSensors(currPos, groundTruth);
  nextState.lastSensorReading = sensor;

  // Check if robot stepped on a hazard
  if (sensor.breachedHazard) {
    nextState.status = 'UNIT_DESTROYED';
    nextState.fatalBreach = {
      position: currPos,
      hazardType: sensor.breachedHazard,
    };
    nextState.confirmedHazards.set(currKey, sensor.breachedHazard);

    nextState.reasoningLog.push({
      id: `log-${nextState.step}-fatal`,
      step: nextState.step,
      timestamp: Date.now(),
      position: currPos,
      type: 'CASUALTY',
      message: `[CRITICAL CASUALTY] Unit breached an undetected ${sensor.breachedHazard.replace('_', ' ')} at (${currPos[0]},${currPos[1]}). Structural integrity lost.`,
      details: `Calculated risk failed. The coordinates have been permanently tagged as confirmed hazard. Intelligence stored for next deployment.`,
    });
    return nextState;
  }

  // Check if survivor is located
  if (sensor.isSurvivor && !nextState.survivorLocated) {
    nextState.survivorLocated = true;
    nextState.reasoningLog.push({
      id: `log-${nextState.step}-survivor`,
      step: nextState.step,
      timestamp: Date.now(),
      position: currPos,
      type: 'SURVIVOR_FOUND',
      message: `[SURVIVOR DETECTED] Human distress beacon confirmed at (${currPos[0]},${currPos[1]}). Survivor secured.`,
      details: `Computing optimal zero-risk extraction vector back to (0,0) across proven safe sectors.`,
    });

    // Compute return plan ONCE via BFS over proven safe cells
    const returnPlan = computeSafeReturnPath(currPos, nextState.provenSafe);
    nextState.returnPlan = returnPlan;
    nextState.returnPlanIndex = 0;
  }

  // 2. PROPOSITIONAL REASONING & UNIT PROPAGATION
  const neighborKeys = getNeighborKeys(currPos[0], currPos[1]);

  if (!sensor.dangerSignal) {
    // AXIOM 1: No danger signal -> EVERY neighbor is immediately provable as safe!
    const newlyProven: string[] = [];
    for (const nKey of neighborKeys) {
      if (!nextState.provenSafe.has(nKey)) {
        nextState.provenSafe.add(nKey);
        newlyProven.push(nKey);
      }
    }

    if (newlyProven.length > 0) {
      nextState.reasoningLog.push({
        id: `log-${nextState.step}-safe`,
        step: nextState.step,
        timestamp: Date.now(),
        position: currPos,
        type: 'DEDUCTION_SAFE',
        message: `No danger signal at (${currPos[0]},${currPos[1]}). Therefore, neighboring cells [${newlyProven.map(k => `(${k})`).join(', ')}] are logically proven SAFE.`,
        details: `Sensor reading: clean. Neighboring perimeter verified secure.`,
      });
    }
  } else {
    // AXIOM 2: Danger signal detected!
    // CRITICAL BUG FIX (from prompt): Check if neighbor already includes an already-confirmed hazard!
    // "If a danger signal's neighbors already include an already-confirmed hazard, the signal is already fully explained —
    // do not create a new candidate set or accuse another neighbor with no evidence."
    const alreadyExplainedHazard = neighborKeys.find((nKey) => nextState.confirmedHazards.has(nKey));

    if (alreadyExplainedHazard) {
      const hazardType = nextState.confirmedHazards.get(alreadyExplainedHazard);
      nextState.reasoningLog.push({
        id: `log-${nextState.step}-explained`,
        step: nextState.step,
        timestamp: Date.now(),
        position: currPos,
        type: 'OBSERVATION',
        message: `Danger signal detected at (${currPos[0]},${currPos[1]}), but it is already fully accounted for by confirmed ${hazardType} at (${alreadyExplainedHazard}).`,
        details: `No new candidate clauses formed; avoiding false accusations against innocent neighbors.`,
      });
    } else {
      // Unexplained danger signal: create a candidate disjunctive clause
      // Hazard must be among neighbors that are NOT yet proven safe
      const unprovenNeighbors = neighborKeys.filter(
        (nKey) => !nextState.provenSafe.has(nKey) && !nextState.confirmedHazards.has(nKey)
      );

      if (unprovenNeighbors.length === 1) {
        // Immediate deduction: only 1 unproven neighbor exists -> it MUST be the hazard!
        const hazardKey = unprovenNeighbors[0];
        const assignedType: HazardType = 'STRUCTURAL_COLLAPSE'; // Default representation in KB
        nextState.confirmedHazards.set(hazardKey, assignedType);

        nextState.reasoningLog.push({
          id: `log-${nextState.step}-sole-hazard`,
          step: nextState.step,
          timestamp: Date.now(),
          position: currPos,
          type: 'DEDUCTION_HAZARD',
          message: `Danger signal detected at (${currPos[0]},${currPos[1]}). All other neighbors are proven safe except (${hazardKey}). By elimination, confirmed HAZARD at (${hazardKey})!`,
          details: `Unit propagation: clause reduced to a singleton set.`,
        });
      } else if (unprovenNeighbors.length > 1) {
        const clauseId = `clause-${currPos[0]}-${currPos[1]}-${Date.now()}`;
        const newClause: CandidateClause = {
          id: clauseId,
          origin: currPos,
          candidates: new Set(unprovenNeighbors),
        };
        nextState.candidateClauses.push(newClause);

        nextState.reasoningLog.push({
          id: `log-${nextState.step}-candidates`,
          step: nextState.step,
          timestamp: Date.now(),
          position: currPos,
          type: 'OBSERVATION',
          message: `Ambiguous danger signal at (${currPos[0]},${currPos[1]}). Hazard is located somewhere in candidate set {${unprovenNeighbors.map(k => `(${k})`).join(', ')}}.`,
          details: `Registered disjunctive clause: (${unprovenNeighbors.join(' ∨ ')}). Awaiting unit propagation.`,
        });
      }
    }
  }

  // 3. UNIT PROPAGATION LOOP
  // Whenever any cell becomes proven safe, prune it from all pending candidate clauses.
  // If a clause shrinks to exactly 1 candidate, confirm that candidate as a hazard by elimination!
  let propagationChanged = true;
  let propagationCycles = 0;

  while (propagationChanged && propagationCycles < 10) {
    propagationChanged = false;
    propagationCycles++;

    const remainingClauses: CandidateClause[] = [];

    for (const clause of nextState.candidateClauses) {
      // 1. Remove all proven safe cells
      let removedSafe = false;
      for (const cand of Array.from(clause.candidates)) {
        if (nextState.provenSafe.has(cand)) {
          clause.candidates.delete(cand);
          removedSafe = true;
          propagationChanged = true;
        }
      }

      // 2. Check if an already confirmed hazard satisfies the clause
      const containsConfirmedHazard = Array.from(clause.candidates).some((cand) =>
        nextState.confirmedHazards.has(cand)
      );

      if (containsConfirmedHazard) {
        // Clause is satisfied and resolved!
        propagationChanged = true;
        continue; // Drop clause
      }

      // 3. Unit propagation check: does clause have exactly 1 member left?
      if (clause.candidates.size === 1) {
        const soleCandidate = Array.from(clause.candidates)[0];
        const assignedType: HazardType = 'STRUCTURAL_COLLAPSE';
        nextState.confirmedHazards.set(soleCandidate, assignedType);
        propagationChanged = true;

        nextState.reasoningLog.push({
          id: `log-${nextState.step}-elimination-${soleCandidate}`,
          step: nextState.step,
          timestamp: Date.now(),
          position: currPos,
          type: 'DEDUCTION_HAZARD',
          message: `[UNIT PROPAGATION] All alternative candidates ruled out for origin (${clause.origin[0]},${clause.origin[1]}). Confirmed HAZARD at (${soleCandidate}) by elimination!`,
          details: `Clause satisfied: member confirmed as hazard. Removed from active uncertainty clauses.`,
        });
        continue; // Clause is resolved
      }

      // Clause still has > 1 candidates
      if (clause.candidates.size > 1) {
        remainingClauses.push(clause);
      }
    }

    nextState.candidateClauses = remainingClauses;
  }

  // 4. RETURNING TO EXTRACTION POINT (If survivor was found or abort initiated)
  if (nextState.returnPlan) {
    // Following BFS precomputed shortest provably-safe path
    const plan = nextState.returnPlan;
    // Current step in return plan
    if (nextState.returnPlanIndex < plan.length - 1) {
      nextState.returnPlanIndex++;
      const nextCoord = plan[nextState.returnPlanIndex];
      nextState.currentPos = nextCoord;

      if (nextCoord[0] === 0 && nextCoord[1] === 0) {
        nextState.status = nextState.survivorLocated ? 'SUCCESS_EXTRACTED' : 'NO_SURVIVOR_FOUND';
        nextState.survivorRescued = nextState.survivorLocated;

        nextState.reasoningLog.push({
          id: `log-${nextState.step}-extracted`,
          step: nextState.step,
          timestamp: Date.now(),
          position: [0, 0],
          type: 'EXTRACTION',
          message: nextState.survivorLocated
            ? `[MISSION SUCCESS] Unit safely returned to extraction point (0,0) with survivor! Extraction completed.`
            : `[EXTRACTION COMPLETE] Unit safely returned to (0,0). Thorough scan exhausted with no survivor detected.`,
          details: `Shortest provably-safe BFS route completed in ${plan.length - 1} extraction steps without incident.`,
        });
      } else {
        nextState.reasoningLog.push({
          id: `log-${nextState.step}-return-step`,
          step: nextState.step,
          timestamp: Date.now(),
          position: nextCoord,
          type: 'EXTRACTION',
          message: `Traversing pre-verified extraction corridor: moved to (${nextCoord[0]},${nextCoord[1]}). (${plan.length - 1 - nextState.returnPlanIndex} steps to extraction base).`,
        });
      }
      return nextState;
    }
  }

  // 5. MOVEMENT STRATEGY: DFS WITH BACKTRACKING & CALCULATED RISK
  // Option A: Prefer an unvisited PROVEN-SAFE neighbor
  const unvisitedSafeNeighbors = neighborKeys
    .filter((nKey) => nextState.provenSafe.has(nKey) && !nextState.visited.has(nKey))
    .map(fromKey);

  if (unvisitedSafeNeighbors.length > 0) {
    // DFS advance: pick first unvisited safe neighbor
    const target = unvisitedSafeNeighbors[0];
    nextState.dfsPath.push(target);
    nextState.currentPos = target;

    nextState.reasoningLog.push({
      id: `log-${nextState.step}-move-safe`,
      step: nextState.step,
      timestamp: Date.now(),
      position: target,
      type: 'OBSERVATION',
      message: `Advancing to unvisited proven-safe neighbor at (${target[0]},${target[1]}).`,
    });
    return nextState;
  }

  // Option B: No unvisited proven-safe neighbor!
  // Check if unvisited neighbors exist that are NOT confirmed hazards (Calculated Risk)
  const candidateNeighbors = neighborKeys
    .filter((nKey) => !nextState.visited.has(nKey) && !nextState.confirmedHazards.has(nKey))
    .map(fromKey);

  if (candidateNeighbors.length > 0) {
    // Evaluate suspicion score for each candidate neighbor
    // Ties broken toward cells NEVER implicated in any danger signal at all
    const scoredCandidates = candidateNeighbors.map((coord) => {
      const cKey = toKey(coord[0], coord[1]);
      const { score, appearances } = calculateSuspicionScore(cKey, nextState.candidateClauses);
      return { coord, cKey, score, appearances };
    });

    // Sort by suspicion score ascending, then by appearances ascending
    scoredCandidates.sort((a, b) => {
      if (a.score !== b.score) return a.score - b.score;
      return a.appearances - b.appearances;
    });

    const chosen = scoredCandidates[0];

    // Take calculated risk!
    nextState.dfsPath.push(chosen.coord);
    nextState.currentPos = chosen.coord;

    nextState.reasoningLog.push({
      id: `log-${nextState.step}-risk`,
      step: nextState.step,
      timestamp: Date.now(),
      position: chosen.coord,
      type: 'RISK_ASSESSMENT',
      message: `No proven-safe unvisited neighbor available. Taking calculated risk on least-suspicious neighbor (${chosen.coord[0]},${chosen.coord[1]}) [Suspicion Score: ${chosen.score.toFixed(2)}, Implicated in ${chosen.appearances} clauses].`,
      details: chosen.appearances === 0
        ? `Cell was never named in any danger clause. Optimal risk-reward choice.`
        : `Cell has lowest danger concentration among remaining unvisited perimeters.`,
    });
    return nextState;
  }

  // Option C: No unvisited neighbors at all -> Backtrack along DFS path
  if (nextState.dfsPath.length > 1) {
    // Pop current cell from stack
    nextState.dfsPath.pop();
    const backtrackTarget = nextState.dfsPath[nextState.dfsPath.length - 1];
    nextState.currentPos = backtrackTarget;

    nextState.reasoningLog.push({
      id: `log-${nextState.step}-backtrack`,
      step: nextState.step,
      timestamp: Date.now(),
      position: backtrackTarget,
      type: 'BACKTRACK',
      message: `Dead end reached with no viable forward cells. Backtracking along verified trail to (${backtrackTarget[0]},${backtrackTarget[1]}).`,
    });
    return nextState;
  }

  // Option D: All reachable safe and risk-viable cells exhausted without finding survivor!
  // Robot must return home via BFS and report "no survivor located in the explored area"
  nextState.reasoningLog.push({
    id: `log-${nextState.step}-exhausted`,
    step: nextState.step,
    timestamp: Date.now(),
    position: currPos,
    type: 'ABORT',
    message: `Exploration space fully exhausted. All reachable safe and viable sectors searched. Survivor was not located in accessible sectors.`,
    details: `Initiating safe withdrawal protocol to extraction point (0,0).`,
  });

  const abortPlan = computeSafeReturnPath(currPos, nextState.provenSafe);
  nextState.returnPlan = abortPlan;
  nextState.returnPlanIndex = 0;

  if (currPos[0] === 0 && currPos[1] === 0) {
    nextState.status = 'NO_SURVIVOR_FOUND';
  }

  return nextState;
}

/**
 * Runs a complete mission programmatically from start to finish.
 * Used for automated verification and stress-testing.
 */
export function runSimulationHeadless(
  groundTruth: GroundTruth,
  maxSteps: number = 200,
  inheritedMemory?: SectorMemory | null
): SimulationState {
  let state = createSimulationState(inheritedMemory);

  while (state.status === 'IN_PROGRESS' && state.step < maxSteps) {
    state = executeSimulationStep(state, groundTruth);
  }

  return state;
}

/**
 * Automated Verification Suite
 * Runs N programmatic missions to confirm:
 * 1. Zero cells are ever wrongly confirmed as a hazard when not one in ground truth.
 * 2. The simulation always terminates (no infinite loops).
 * 3. Genuine distribution of success, casualties, and safe returns.
 */
export function runBatchVerification(numRuns: number = 100): {
  totalRuns: number;
  successfulExtractions: number;
  unitsDestroyed: number;
  noSurvivorOutcomes: number;
  falseHazardAccusations: number;
  timedOutRuns: number;
  solvabilityViolations: number;
  avgSteps: number;
  executionTimeMs: number;
} {
  const startTime = performance.now();
  let successful = 0;
  let destroyed = 0;
  let noSurvivor = 0;
  let falseAccusations = 0;
  let timedOut = 0;
  let solvabilityViolations = 0;
  let totalSteps = 0;

  for (let i = 0; i < numRuns; i++) {
    const env = generateSolvableEnvironment();

    if (!isSurvivorReachable(env)) {
      solvabilityViolations++;
    }

    const state = runSimulationHeadless(env, 250);
    totalSteps += state.step;

    if (state.status === 'IN_PROGRESS') {
      timedOut++;
    } else if (state.status === 'SUCCESS_EXTRACTED') {
      successful++;
    } else if (state.status === 'UNIT_DESTROYED') {
      destroyed++;
    } else if (state.status === 'NO_SURVIVOR_FOUND') {
      noSurvivor++;
    }

    // AUDIT SOUNDNESS: Check that zero cells in confirmedHazards are false accusations
    for (const [hazardKey] of state.confirmedHazards.entries()) {
      if (!env.hazards[hazardKey]) {
        falseAccusations++;
      }
    }
  }

  const executionTimeMs = performance.now() - startTime;

  return {
    totalRuns: numRuns,
    successfulExtractions: successful,
    unitsDestroyed: destroyed,
    noSurvivorOutcomes: noSurvivor,
    falseHazardAccusations: falseAccusations,
    timedOutRuns: timedOut,
    solvabilityViolations: solvabilityViolations,
    avgSteps: Math.round((totalSteps / numRuns) * 10) / 10,
    executionTimeMs: Math.round(executionTimeMs),
  };
}
